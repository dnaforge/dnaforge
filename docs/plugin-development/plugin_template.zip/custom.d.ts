declare namespace api {
  class Graph {
    vertices: Vertex[];
    edges: Edge[];
    faces: Face[];

    toJSON(): JSONObject;
    static loadJSON(json: any): Graph;
    getStatistics(): {
      Nodes: number;
      Edges: number;
      Faces: number;
      'Min d': number;
      'Max d': number;
      Eulerian: string;
    };
    calculateNormals(): void;
    calculateNormalsOutside(): void;
    flipNormals(): void;
    getVertices(): Vertex[];
    getEdges(): Edge[];
    getFaces(): Face[];
    addVertex(coords: THREE.Vector3, normal?: THREE.Vector3, id?: number): Vertex;
    addEdge(v1: Vertex, v2: Vertex, normal?: THREE.Vector3, id?: number): Edge;
    addFace(edges: Edge[], normal?: THREE.Vector3, id?: number): Face;
    hasFaceInformation(): boolean;
    clone(): Graph;
    dijkstra(v1: Vertex, v2: Vertex): {
      path: Edge[];
      length: any;
    };
    splitEdge(edge: Edge): Edge;
    isEulerian(): boolean;
    makeEulerian(randomSeed?: number): {
      path: Edge[];
      length: number;
    }[];
    makeCheckerBoard(): void;
    getGenus(): number;
  }

  class HalfEdge {
    edge: Edge;
    vertex: Vertex;
    twin: HalfEdge;

    constructor(edge: Edge, vertex: Vertex);

    getDirection(): THREE.Vector3;
    toString(): string;
  }

  class Vertex {
    id: number;
    coords: THREE.Vector3;
    normal: THREE.Vector3;
    adjacentEdges: Edge[];

    constructor(id: number, coords: THREE.Vector3, normal?: THREE.Vector3);

    toString(): string;
    addNeighbour(edge: Edge): void;
    getNeighbours(): Vertex[];
    getTopoNeighbours(): Vertex[];
    getTopoAdjacentEdges2(): Edge[];
    getTopoAdjacentEdges(): Edge[];
    getAdjacentHalfEdges(): HalfEdge[];
    getTopoAdjacentHalfEdges(): HalfEdge[];
    getAdjacentEdges(): Edge[];
    getCommonEdges(other: Vertex): Edge[];
    getAdjacentFaces(): Face[];
    getTopoAdjacentFaces(): Face[];
    degree(): number;
  }

  class Edge {
    id: number;
    vertices: Vertex[];
    halfEdges: HalfEdge[];
    faces: Face[];
    normal: THREE.Vector3;

    constructor(id: number, v1: Vertex, v2: Vertex, normal?: THREE.Vector3);

    toString(): string;
    getOutwardHalfEdge(start: Vertex): HalfEdge;
    isSplit(): boolean;
    getVertices(): Vertex[];
    getCoords(): [THREE.Vector3, THREE.Vector3];
    getFaces(): Face[];
    getOtherVertex(v: Vertex): Vertex;
    getCommonVertex(e: Edge): Vertex;
    addFace(f: Face): void;
    getLength(): number;
    getAdjacentEdges(): Set<Edge>;
  }

  class Face {
    id: number;
    edges: Edge[];
    normal: THREE.Vector3;

    constructor(id: number, edges: Edge[], normal?: THREE.Vector3);

    getFaceCycle(start: HalfEdge): HalfEdge[];
    triangulate(): [Vertex, Vertex, Vertex][];
    getEdges(): Edge[];
    isSplit(): boolean;
    getVertices(): Set<Vertex>;
    getNeighbours(): Face[];
    getCommonEdge(f: Face): Edge;
  }

  abstract class WiresModel {
    graph: Graph;
    obj?: THREE.InstancedMesh;
    owner?: ModuleMenu;
    coords?: THREE.Vector3[][];

    abstract toJSON(): JSONObject;
    abstract toObj(): string;

    _toObj(...coords: THREE.Vector3[][]): string;
    solveIntersection(i: THREE.Intersection): Selectable | null;
    getStatistics(): JSONObject;
    dispose(): void;
    show(): void;
    hide(): void;
    getVertexOffset(v1: Vertex, v2: Vertex, scaleFactor: number): THREE.Vector3;
    getScaleFactor(): number;
    _generateObject(coords: THREE.Vector3[][]): THREE.Object3D;
    updateObject(): void;
  }

  class CylinderModel {
    cylinders: Cylinder[];
    scale: number;
    naType: any;
    nucParams: any;
    obj?: THREE.Object3D;
    owner?: ModuleMenu;
    meshes?: any;
    selection: Set<Selectable>;

    constructor(scale: number, name: string);
    toJSON(): JSONObject;
    static loadJSON(json: any): void;
    getStatistics(): JSONObject;
    addCylinders(...cyls: Cylinder[]): void;
    createCylinder(startP: THREE.Vector3, dir: THREE.Vector3, length_bp: number): Cylinder;
    getCylinders(): Cylinder[];
    getVertexOffset(v1: Vertex, v2: Vertex, greedy: boolean): THREE.Vector3;
    show(): void;
    hide(): void;
    dispose(): void;
    generateObject(): THREE.Object3D<THREE.Event>;
    solveIntersection(i: THREE.Intersection): Selectable;
    updateObject(): void;
    relax(params: any): Promise<void>;
    calculateRelaxScore(): number;
    getSelection(event: string, target?: Selectable, mode?: any): Selectable[];
    getConnected(target: Cylinder, mode: any): Cylinder[];
  }

  class NucleotideModel {
    idToNuc: Map<number, Nucleotide>;
    strands: Strand[];
    scale: number;
    naType: any;
    nucParams: any;
    obj?: THREE.Object3D;
    owner?: ModuleMenu;

    constructor(scale: number, naType?: any);

    toJSON(): JSONObject;
    static loadJSON(json: any): NucleotideModel;
    getStatistics(): JSONObject;
    loadOxDNA(top: string, conf: string, scale: number, naType?: any): NucleotideModel;
    updateFromOxDNA(conf: string): void;
    toDat(): string;
    toTop(): string;
    toExternalForces(stiffness?: number): string;
    toStrands(): string;
    toUNF(): JSONObject;
    toPDB(): string;
    addStrand(strand: Strand): void;
    length(): number;
    static compileFromGenericCylinderModel(cm: CylinderModel, params: ModuleMenuParameters, hasScaffold?: boolean): NucleotideModel;
    validate(hasNicks: boolean, minLength: number, maxLength: number): void;
    createStrands(cm: CylinderModel, hasScaffold: boolean, hybrid?: boolean): Map<Cylinder, [Strand, Strand]>;
    linkStrands(cm: CylinderModel, cylToStrands: Map<Cylinder, [Strand, Strand]>, minLinkers: number, maxLinkers: number): void;
    concatenateStrands(): void;
    setIDs(): void;
    addNicks(minLength: number, maxLength: number): void;
    getNucleotides(): Nucleotide[];
    getStrands(): Strand[];
    getScaffold(): Strand;
    setPrimary(str: string | string[]): void;
    show(): void;
    hide(): void;
    dispose(): void;
    generateObject(): THREE.Object3D<THREE.Event>;
    solveIntersection(i: THREE.Intersection): Nucleotide;
    updateObject(): void;
    getSelection(event: string, target?: Selectable, mode?: any): Selectable[];
    get5ps(): Nucleotide[];
    getConnected(target: Nucleotide, mode: any): Nucleotide[];
  }

  class Nucleotide extends Selectable {
    owner: NucleotideModel;
    strand: Strand;
    id: number;
    obj3d: any;
    base: any;
    scale: number;
    naType: any;
    nucParams: any;
    isLinker: boolean;
    isScaffold: boolean;
    isPseudo: boolean;
    prev: Nucleotide | null;
    next: Nucleotide | null;
    pair: Nucleotide | null;
    transform: THREE.Matrix4;
    backboneCenter: THREE.Vector3;
    nucleobaseCenter: THREE.Vector3;
    hydrogenFaceDir: THREE.Vector3;
    baseNormal: THREE.Vector3;

    constructor(nm: NucleotideModel, strand: Strand, base?: any);

    toJSON(): JSONObject;
    static loadJSON(nm: NucleotideModel, strand: Strand, json: any): Nucleotide;
    setTransformFromOxDNA(com: THREE.Vector3, a1: THREE.Vector3, a3: THREE.Vector3): void;
    delete(): void;
    setNucleotideVectors(): void;
    setObjectInstance(obj: any): void;
    updateObjectMatrices(): void;
    updateObjectColours(): void;
    updateObjectVisibility(): void;
    toUNF(): {
      id: number;
      nbAbbrev: any;
      pair: number;
      prev: number;
      next: number;
      pdbId: number;
      altPositions: {
        nucleobaseCenter: number[];
        backboneCenter: number[];
        baseNormal: number[];
        hydrogenFaceDir: number[];
      }[];
    }
    linkNucleotides(other: Nucleotide, N: number): Nucleotide[];
    updateVisuals(): void;
    getTooltip(): string;
    getTransform(): THREE.Matrix4;
    getPosition(): THREE.Vector3;
    getRotation(): THREE.Quaternion;
    getSize(): number;
    setTransform(m: THREE.Matrix4): void;
    setRotation(rot: THREE.Quaternion): void;
  }

  class Cylinder {
    owner: CylinderModel;
    id: number;
    scale: number;
    naType: any;
    length: number;
    transform: THREE.Matrix4;
    routingStrategy: RoutingStrategy;
    bundle: CylinderBundle;
    neighbours: Record<PrimePos, [Cylinder, PrimePos]>
    instanceMeshes: any;
    nucParams: any;

    constructor(
      cm: CylinderModel,
      id: number,
      length: number,
      naType: any,
      routingStrategy: RoutingStrategy
    );

    toJSON(): JSONObject;
    createInstanceMesh(nucParams: any, count: number): any;
    getTransform(): THREE.Matrix4;
    setTransform(m: THREE.Matrix4): void;
    getLength(): number;
    getCylinderLength(): number;
    getP1(): THREE.Vector3;
    initTransformMatrix(startP: THREE.Vector3, dir: THREE.Vector3): void;
    initOrientation(bb: THREE.Vector3): void;
    setRotation(rot: THREE.Quaternion): void;
    setPosition(newPos: THREE.Vector3): void;
    setSize(len: number): void;
    getPosition(): THREE.Vector3;
    getRotation(): THREE.Quaternion;
    getSize(): number;
    update(): void;
    getPrimePositionU(ps: PrimePos): THREE.Vector3;
    getPrimePosition(pp: PrimePos): THREE.Vector3;
    getPairPrimePositionU(pp: PrimePos): THREE.Vector3;
    getPairPrimePosition(pp: PrimePos): THREE.Vector3;
    getStrand1Matrices(): IterableIterator<THREE.Matrix4>;
    getStrand2Matrices(): IterableIterator<THREE.Matrix4>;
    getPrimePairs(): [THREE.Vector3, THREE.Vector3][];
    setObjectInstance(meshes: any): void;
    updateObjectMatrices(): void;
    updateObjectColours(): void;
    getOverlayColours(colour: THREE.Color): THREE.Color;
    calculateTorque(): number;
    calculateTension(): number;
    getTooltip(): string;
  }

  class CylinderBundle {
    isRigid: boolean;
    cylinders: Cylinder[];
    length: number;

    constructor(...cylinders: Cylinder[]);

    push(...cylinders: Cylinder[]): void;
    toJSON(): JSONObject;
  }

  enum PrimePos {
    first5 = 'f5', // first 5'
    second5 = 's5', // second 5'
    first3 = 'f3', // first 3'
    second3 = 's3', // second 3'
  }

  enum RoutingStrategy {
    Normal = 0,
    Pseudoknot = 1,
    Reinforced = 2,
    Veneziano = 3,
    SixHelix = 4,
  }

  class Strand {
    owner: NucleotideModel;
    id: number;
    nucleotides: Nucleotide[];
    scale: number;
    naType: any;
    nucParams: any;
    pair: Strand;
    isScaffold: boolean;
    isLinker: boolean;
    isPseudo: boolean;

    constructor(nm: NucleotideModel);

    toJSON(): JSONObject;
    static loadJSON(nm: NucleotideModel, json: any): Strand;
    getNucleotides(): Nucleotide[];
    generateNucleotides(...matrices: THREE.Matrix4[]): void;
    addBasePairs(strand2: Strand): void;
    addNucleotides(...n: Nucleotide[]): void;
    deleteNucleotides(...n: Nucleotide[]): void;
    linkStrand(next: Strand, min?: number, max?: number): Strand | undefined;
    toPrimary(): string;
    toUNF(): {
      id: number;
      isScaffold: boolean;
      naType: any;
      color: string;
      fivePrimeId: number;
      threePrimeId: number;
      pdbFileId: number;
      chainName: string;
      nucleotides: {
        id: number;
        nbAbbrev: any;
        pair: number;
        prev: number;
        next: number;
        pdbId: number;
        altPositions: {
          nucleobaseCenter: number[];
          backboneCenter: number[];
          baseNormal: number[];
          hydrogenFaceDir: number[];
        }[];
      }[]
    };
    length(): number;
  }

  class Context {
    controls: any;
    editor: any;
    scene: THREE.Scene;
    camera: THREE.Camera;
    cameraControls: THREE.ArcballControls;
    callbacks: { (): void };
    graph: Graph;
    activeContext: ModuleMenu;
    renderer: THREE.WebGLRenderer;
    labelRenderer: THREE.CSS2DRenderer;
    menus: Map<string, any>;
    tooltip: {
      object: THREE.Object3D;
      div: HTMLElement;
    };
    statsNeedsUpdate: boolean;
    uiNeedsUpdate: boolean;
    rendererNeedsUpdate: boolean;
    isAnimating: boolean;

    constructor();

    setupHotkeys(): void;
    registerMenu(menu: any): void;
    setupRenderer(): void;
    start(): void;
    render: () => void;
    startAnimation(): void;
    endAnimation(): void;
    updateSceneStatistics(): void;
    updateSelectors(): void;
    updateArcDiagram(): void;
    getScreenshot(): void;
    resetSize(): void;
    focusCamera(target: THREE.Vector3): void;
    setCameraView(dir: string): void;
    rotateCameraView(dir: string): void;
    flipCameraView(): void;
    getCamera(): THREE.Camera;
    resetCamera(toOrthographic: boolean): void;
    setOrthographicCamera(): void;
    setPerspectiveCamera(): void;
    addMessage(message: string, type: string, duration?: number): void;
    closeMessage(el: any, timeout: number): Promise<void>;
    toJSON(selection: JSONObject): JSONObject;
    static loadJSON(json: any): void;
    refresh(): void;
    reset(): void;
    setGraph(graph: Graph): void;
    addTooltip(point: THREE.Vector3, content: string): void;
    removeTooltip(): void;
    createWindow(): void;
    switchContext(context: ModuleMenu): void;
    switchMainTab(id: string): void;
    setupEventListeners(): void;
  }

  abstract class ModuleMenu {
    params: ModuleMenuParameters;

    wires: WiresModel;
    cm: CylinderModel;
    nm: NucleotideModel;

    wiresButton: any;
    cylindersButton: any;
    nucleotidesButton: any;
    relaxButton: any;
    generateWiresButton: any;
    generateCylindersButton: any;
    generateNucleotidesButton: any;
    context: Context;

    constructor(context: Context, html: string);

    toJSON(selection: JSONObject): JSONObject;
    static loadJSON(json: any): void;
    loadOxDNA(top: string, conf: string, scale: number, naType: any): void;
    updateFromOxDNA(conf: string): void;
    registerHotkeys(): void;
    jsonToWires(json: JSONObject): WiresModel;
    graphToWires(graph: Graph, params: ModuleMenuParameters): WiresModel;
    wiresToCylinders(wires: WiresModel, params: ModuleMenuParameters): CylinderModel;
    cylindersToNucleotides(cm: CylinderModel, params: ModuleMenuParameters): NucleotideModel;
    activate(): void;
    inactivate(): void;
    reset(): void;
    generateWires(): void;
    generateCylinderModel(): void;
    generateNucleotideModel(): void;
    relaxCylinders(): Promise<void>;
    removeWires(dispose?: boolean): void;
    removeCylinders(dispose?: boolean): void;
    removeNucleotides(dispose?: boolean): void;
    generateVisible(): void;
    updateVisuals(): void;
    downloadUNF(): void;
    downloadOx(): void;
    downloadStrands(): void;
    downloadObj(): void;
    downloadPDB(): void;
    generateWiresOP(): void;
    generateCylindersOP(): void;
    generateNucleotidesOP(): void;
    setupEventListeners(): void;
    collectParameters(): void;
    registerParameter<T>(dict: T, parameter: keyof T, id: string, fromHTMLTrans?: (t: any) => any, toHTMLTrans?: (t: any) => any): void

  }

  namespace THREE {
    class Vector3 {
      x: number;
      y: number;
      z: number;
      constructor(x?: number, y?: number, z?: number);
      clone(): Vector3;
      sub(v: Vector3): Vector3;
      normalize(): Vector3;
      multiplyScalar(s: number): Vector3;
      distanceTo(v: Vector3): number;
      length(): number;
      cross(a: Vector3): THREE.Vector3;
      add(v: Vector3): THREE.Vector3;
      dot(v: Vector3): number;
      negate(): THREE.Vector3;
      applyAxisAngle(axis: Vector3, angle: number): THREE.Vector3;
      copy(v: Vector3): THREE.Vector3;
      applyMatrix4(m: Matrix4): THREE.Vector3;
    }

    class Matrix4 {
      constructor();
      multiply(m: Matrix4): Matrix4;
      makeRotationFromQuaternion(q: Quaternion): Matrix4;
      setPosition(v: Vector3): void;
      clone(): Matrix4;
      copyPosition(m: Matrix4): Matrix4;
    }

    class Quaternion {
      x: number;
      y: number;
      z: number;
      w: number;
      constructor(x?: number, y?: number, z?: number, w?: number);
      setFromUnitVectors(vFrom: Vector3, vTo: Vector3): Quaternion;
    }

    class Object3D<E extends THREE.BaseEvent = THREE.Event> {
      position: Vector3;
      rotation: Euler;
      quaternion: Quaternion;
      add(...objects: Object3D[]): void;
    }

    class BaseEvent { }

    class Euler {
      x: number;
      y: number;
      z: number;
      constructor(x?: number, y?: number, z?: number, order?: string);
    }

    class InstancedMesh { }

    class Intersection {
      distance: number;
      point: Vector3;
      object: Object3D;
    }

    class Camera extends Object3D { }

    class Scene extends Object3D { }

    class WebGLRenderer {
      domElement: HTMLElement;
      render(scene: Scene, camera: Camera): void;
      setSize(width: number, height: number): void;
    }

    class CSS2DRenderer {
      domElement: HTMLElement;
      render(scene: Scene, camera: Camera): void;
      setSize(width: number, height: number): void;
    }

    class ArcballControls {
      constructor(camera: Camera, domElement: HTMLElement, scene: Scene);
      update(): void;
      dispose(): void;
    }

    class Event {
      type: string;
      target: any;
    }

    class Color { }
  }


  abstract class Selectable {
    owner: any;
    selectionStatus: any;

    abstract getTooltip(): string;
    abstract updateObjectColours(): void;

    setSelectionStatus(status: any): void;
    getTransform(): THREE.Matrix4;
    getPosition(): THREE.Vector3;
    getRotation(): THREE.Quaternion;
    getSize(): number;
  }

  class PrimaryGenerator {
    nm: api.NucleotideModel;
    pairs: Map<number, number>;
    idxToBounds: Map<number, [number, number]>;
    linkerIndices: Set<number>;

    params: OptimiserParams;

    pString: string[];
    numGC: number;
    linkerOptions: string[];
    curLen: number;
    subSeqs: Map<number, Map<string, Set<number>>>;
    repeats: Map<number, any>;
    isConflict: (seq: string) => boolean;
    conflicts: any;

    constructor(nm: NucleotideModel, optimiserParams?: Partial<OptimiserParams>);

    optimise(): void;
    getLongestRepeat(): number;
    getGCContent(): number;
  }

  function setPrimaryFromScaffold(nm: NucleotideModel, params: any, hybrid?: boolean): string[];

  function editOp(...t: string[]): (target: any, methodName: string) => any;

  function getNP(nm: NucleotideModel): string;

  function setRandomPrimary(nm: NucleotideModel, gcContent: number, naType: any, ignoreExisting?: boolean): string[];

  function setPartialPrimaryRNA(nm: NucleotideModel): string[];

  function xtrnaParameters(graph: Graph): {
    st: Set<Edge>;
    rotations: Map<Vertex, HalfEdge[]>;
    kls: Set<HalfEdge>;
    trail: HalfEdge[];
  };

  function getVertexRotations(graph: Graph, st: Set<Edge>): Map<Vertex, HalfEdge[]>;

  function augmentRotations(graph: Graph, rotations: Map<Vertex, HalfEdge[]>): Set<HalfEdge>;

  function downloadTXT(filename: string, text: string): void;

}

interface OptimiserParams {
  maxTrials: number;
  iterations: number;
  eta: number;

  gcContent: number;
  linkerOptions: any;
  bannedSeqs: string[];
}

interface ModuleMenuParameters {
  //secondary structure
  naType?: 'DNA' | 'RNA';
  scale: number;
  minLinkers?: number;
  maxLinkers?: number;
  linkerOptions?: any;
  minStrandLength?: number;
  maxStrandLength?: number;
  addNicks?: boolean;
  greedyOffset?: boolean;

  //primary structure
  gcContent?: number;
  scaffoldName?: string;
  customScaffold?: string;
  scaffoldOffset?: number;
  scaffoldStart?: number;

  //visibility
  showWires?: boolean;
  showCylinders?: boolean;
  showNucleotides?: boolean;

  //relaxer
  relaxIterations?: number;
  springConstraints?: boolean;
  floorConstraints?: boolean;
  bundleConstraints?: boolean;
}

declare function $(selector: any): any;
declare const Metro: any;

declare const context: api.Context;

type JSONValue = JSONObject | string | number | boolean | Array<JSONValue>;

interface JSONObject {
  [x: string]: JSONValue;
}

