/**
 * HTML layout for the Template plugin UI in DNAForge.
 *
 * This defines the user interface for a general module, built on the Metro 4 UI library (v4.3.10).
 * You may customize the layout as needed. Refer to Metro 4 documentation for component details: https://metroui.org.ua
 *
 * The current UI components include:
 *  - "Generate Design" button: Initiates route generation for the model.
 *  - Visibility toggles: Switches for displaying wires, cylinders, and nucleotides.
 *  - Scale input: Accepts a numerical value in nanometers for model scaling.
 *  - Scaffold selector: Dropdown for choosing the primary structure of the scaffold strand (for when there is a scaffold strand).
 *  - Model control buttons:
 *      - Cylinder relaxation (optional, currently hidden)
 *      - Nucleotide generation based on the cylinder model
 *  - Download options:
 *      - Unified Nanotechnology Format (UNF)
 *      - PDB file
 *      - oxDNA (classic format)
 *      - oxNA (new format)
 *      - Primary strand structure
 *  - Dialogs:
 *      - Custom scaffold input (you have no access to this via the current UI)
 *      - Additional parameter configuration, including:
 *          - Scaffold offset input
 *          - 5' scaffold start ID input
 *          - GC content (for random scaffold generation, currently hidden)
 *          - Relaxation constraints (edge, bundle, and spring)
 *
 * Each UI element has a 'data-hint-*' for tooltips.
 * 
 * Make sure that each element has an unique id, and there are no duplicate ids with other plugins or built-in scripts.
 */
const pluginHTML = `
<div class="section" id="template" data-title="Template"
      data-hint-text="Hint text describing the module.">
          <div class="group">
              <button class="ribbon-button" id="template-generate-wires" data-role="hint"
                  data-hint-position="right"
                  data-hint-text="Generate the route">
                  <span class="mif-play mif-4x"></span>
                  <span class="caption">Generate<br>Design</span>
              </button>
              <span class="title">Main</span>
          </div>
          <div class="group">
              <ul style="list-style-type:none;">
                  <li data-role="hint" data-hint-position="right" data-hint-text="Toggle visibility of the routing.">
                      <input type="checkbox" data-role="switch" data-caption="Route" id="template-toggle-wires">
                  </li>
                  <li data-role="hint" data-hint-position="right"
                      data-hint-text="Toggle visibility of the cylinder model."><input type="checkbox" data-role="switch"
                          data-caption="Cylinders" id="template-toggle-cylinders"></li>
                  <li data-role="hint" data-hint-position="right"
                      data-hint-text="Toggle visibility of the nucleotide model."><input checked type="checkbox"
                          data-role="switch" data-caption="Nucleotides" id="template-toggle-nucleotides"></li>
              </ul>
              <span class="title">Visibility</span>
          </div>
          <div class="group">
              <ul style="list-style-type:none;">
                  <li data-role="hint" data-hint-position="right"
                      data-hint-text="Input scale in nanometers. This is the edge length of each reference grid square.">
                      <input type="number" data-role="input" data-default-value="5" min="0.1" max="1000" step="0.1"
                          data-size="225" data-prepend="Scale" data-append="nm" id="template-scale"></li>
                  <li data-role="hint" data-hint-position="right" data-hint-text="Scaffold strand primary structure.">
                      <select data-prepend="Scaffold" data-role="select" id="template-scaffold">
                          <optgroup label="Scaffold Strand">
                              <option value="none">Blank</option>
                              <option value="m13mp18">M13mp18 (7249)</option>
                              <option value="p7560">p7560 (7560)</option>
                              <option value="p8064">p8064 (8064)</option>
                              <option value="p8634">p8634 (8634)</option>
                              <option value="p7308">p7308 (7308)</option>
                              <option value="p7704">p7704 (7704)</option>
                              <option value="p8100">p8100 (8100)</option>
                              <option value="random">Random</option>
                              <option value="custom">Custom</option>
                          </optgroup>
                      </select>
                  </li>
              </ul>
              <button class="ribbon-button" onclick="Metro.dialog.open('#template-parameters');" data-role="hint"
                  data-hint-position="right" data-hint-text="Setup additional Template parameters.">
                  <span class="mif-cogs mif-4x"></span>
                  <span class="caption">Additional<br>Parameters</span>
              </button>
              <span class="title">Parameters</span>
          </div>
          <div class="group">
              <button hidden class="ribbon-button" id="template-relax" data-role="hint" data-hint-position="right"
                  data-hint-text="">
                  <span class="mif-shrink2 mif-4x"></span>
                  <span class="caption">Relax<br>Cylinder<br>Model</span>
              </button>
              <button class="ribbon-button" id="template-generate-nucleotides" data-role="hint"
                  data-hint-position="right"
                  data-hint-text="Generate a nucleotide model based on the current cylinder model. Also assigns bases identities if the scaffold strand is defined.">
                  <span class="mif-shuffle mif-4x"></span>
                  <span class="caption">Generate<br>Nucleotide<br>Model</span>
              </button>
              <span class="title">Generation</span>
          </div>
          <div class="group">
              <ul style="list-style-type:none;">
                  <li>
                      <button class="button light w-100 small" id="template-download-unf" data-role="hint"
                          data-hint-position="right"
                          data-hint-text="Download the current nucleotide model as a Unified Nanotechnology Format file.">
                          <span class="mif-download mif-2x"></span>
                          <span class="caption">Download UNF</span>
                      </button>
                  </li>
                  <li>
                      <button class="button light w-100 small" id="template-download-pdb" data-role="hint"
                          data-hint-position="right" data-hint-text="Download the current nucleotide model as a pdb.">
                          <span class="mif-download mif-2x"></span>
                          <span class="caption">Download PDB</span>
                      </button>
                  </li>
                  <li>
                      <button class="button light w-100 small" id="template-download-ox" data-role="hint"
                          data-hint-position="right"
                          data-hint-text="Download the current nucleotide model as classic oxDNA files.">
                          <span class="mif-download mif-2x"></span>
                          <span class="caption">Download oxDNA (classic)</span>
                      </button>
                  </li>
                  <li>
                      <button class="button light w-100 small" id="template-download-ox-new" data-role="hint"
                          data-hint-position="right"
                          data-hint-text="Download the current nucleotide model as new oxNA files.">
                          <span class="mif-download mif-2x"></span>
                          <span class="caption">Download oxNA</span>
                      </button>
                  </li>
                  <li>
                      <button class="button light w-100 small" id="template-download-strands" data-role="hint"
                          data-hint-position="right" data-hint-text="Download the primary structure.">
                          <span class="mif-download mif-2x"></span>
                          <span class="caption">Download Strands</span>
                      </button>
                  </li>
              </ul>
              <span class="title">Download</span>
          </div>
      </div>
  </div>

  <div class="dialog" data-role="dialog" id="template-scaffold-dialog" data-overlay-click-close="true">
      <div class="dialog-title">Input a custom scaffold</div>
      <div class="dialog-content">
          <textarea data-role="textarea" data-chars-counter="#template-chars-counter"
              data-chars-counter-template="Length $1 bases" id="template-scaffold-dialog-text"
              data-auto-size="false"></textarea>
          <p id="template-chars-counter">Length: 0 bases</p>
      </div>
      <div class="dialog-actions">
          <button class="button js-dialog-close">Cancel</button>
          <button class="button primary js-dialog-close" id="template-scaffold-dialog-confirm">Set
              Scaffold</button>
      </div>
  </div>

<div class="dialog" data-role="dialog" id="template-parameters" data-overlay-click-close="true">
    <div class="dialog-title">Template settings</div>
    <div class="dialog-content" style="overflow-y: scroll;">
                <p>Routing parameters:</p>
        <ul class="group-list">
            <li data-role="hint" data-hint-position="right"
                data-hint-text="Bring cylinders as close to the node as possible.">
                <input type="checkbox" data-role="checkbox" data-caption="Minimise steric zones at nodes"
                    id="template-greedy">
            </li>
        </ul>
        <p>Strand parameters:</p>
        <ul class="group-list">
            <li data-role="hint" data-hint-position="right"
                data-hint-text="Offset for the scaffold. Ignore this many bases from scaffold start.">
                <input type="number" data-role="input" data-default-value="0" data-prepend="Offset"
                    id="template-scaffold-offset">
            </li>
            <li data-role="hint" data-hint-position="right"
                data-hint-text="ID of the first nucleotide in the scaffold strand.">
                <input type="number" data-role="input" data-default-value="0" data-prepend="5' ID"
                    id="template-scaffold-start">
            </li>
            <li hidden data-role="hint" data-hint-position="right"
                data-hint-text="Proportion of G's and C's in the randomly generated primary structure."><input
                    type="number" data-role="input" data-default-value="50" data-size="260" data-prepend="GC-content"
                    data-append="%" id="template-gc-content"></li>
        </ul>
        <p>Relaxation parameters:</p>
        <ul class="group-list">
            <li hidden data-role="hint" data-hint-position="right"
                data-hint-text="Number of relaxation simulation iterations."><input type="number" data-role="input"
                    data-default-value="50" data-prepend="GC-content" data-append="%"
                    id="template-relax-iterations"></li>
            <li data-role="hint" data-hint-position="right"
                data-hint-text="Add springs between the mesh edges and cylinders.">
                <input checked type="checkbox" data-role="checkbox" data-caption="Edge Constraints"
                    id="template-floor-constraints">
            </li>
            <li data-role="hint" data-hint-position="right"
                data-hint-text="Add springs between cylinders in bundles, e.g. reinforced cylinders or doubled edges.">
                <input checked type="checkbox" data-role="checkbox" data-caption="Bundle Constraints"
                    id="template-bundle-constraints">
            </li>
            <li data-role="hint" data-hint-position="right"
                data-hint-text="Add springs between 3'- and 5'-primes of neighbouring cylinders.">
                <input checked type="checkbox" data-role="checkbox" data-caption="Spring Constraints"
                    id="template-spring-constraints">
            </li>
        </ul>
    </div>
    <div class="dialog-actions">
        <button class="button js-dialog-close">Close</button>
    </div>
</div>`

/**
 * This template class defines a skeleton version of a routing module for DNAForge.
 * 
 * This class follows the same structural pattern as other built-in routing modules in DNAForge,
 * extending the WiresModel abstract class (of which you can find further information from 
 * https://github.com/dnaforge/dnaforge/blob/main/src/scripts/models/wires_model.ts).
 */
class Template extends api.WiresModel {
  // Currently the template class has the properties:

  /**
   * Mandatory for all 'WiresModel' subclasses
   * 
   * Structure of the original 3D model as the type of DNAForge's own graph class
   * with edges, vertices, and (possibly) faces.
   */
  graph: api.Graph;

  /**
   * An array of 'api.HalfEdge' objects defining the specific path or route that is generated by this module.
   */
  trail: Array<api.HalfEdge>;

  /**
   * A polygon mesh representing the 3d object associated with this module's route.
   */
  obj: api.THREE.InstancedMesh;

  /**
   * You can modify these properties how you'd like (add/delete), however all WiresModel extensions 
   * need to have at least the 'graph' property of type api.Graph.
   */


  /**
   * Mandatory for all 'WiresModel' subclasses
   * 
   * Defines how the module class is initialized.
   * 
   * The constructor can be left as simple as this. 
   * You can have more parameters if you'd like and/or add more logic to it. 
   * See for example ST-DNA's constructor: https://github.com/dnaforge/dnaforge/blob/main/src/scripts/modules/stdna/stdna.ts
   * or XT-RNA's constructor: https://github.com/dnaforge/dnaforge/blob/main/src/scripts/modules/xtrna/xtrna.ts
   * 
   * @param graph The graph to be used in this routing instance.
   * @param params The parameters you want to use in this module.
   */
  constructor(graph: api.Graph, params?: TemplateParameters) {
    super(); // Initializes the base WiresModel class
    this.graph = graph; // Assigns the input graph to this instance
  }

  /**
   * Mandatory for all 'WiresModel' subclasses
   * 
   * Serializes the Template instance into a JSON-compatible object.
   * 
   * This method is used to export the module's state to a JSON object (accessible by clicking 
   * 'Save as JSON' button in File-tab, which saves the current program state as a JSON-file).
   * 
   * In this base template, the function only exports the 'graph' property to a JSONObject. Complete modules 
   * (for example 'ATrail') also include some of the additional class properties like the computed 
   * 'trail' in their output.
   *
   * @returns A JSON object with at least a 'graph' field.
   */
  toJSON(): JSONObject {
    const graph = this.graph.toJSON(); // Transforms this module's graph to a JSON object
    return { graph: graph };
  }

  /**
   * Mandatory for all 'WiresModel' subclasses
   * 
   * Reconstructs a module instance from a JSON object.
   * 
   * This function can again be more complicated depending on your module and how it works, 
   * but this is the bare minimum. The built-in design method modules also usually at least
   * set the 'trail' value for the class in addition to 'graph'.
   * 
   * @param json A JSON object containing serialized information.
   * 
   * @returns An instance of the module initialized with the provided JSON data.
   */
  static loadJSON(json: any) {
    const graph = api.Graph.loadJSON(json.graph); // Creates a graph of type 'Graph' from the JSON data
    const t = new Template(graph); // Initializes the module with the created graph
    return t;
  }

  /**
   * Mandatory for all 'WiresModel' subclasses.
   * 
   * Converts the current trail into a Wavefront '.obj' format string.
   * This method extracts the 3D coordinates of each vertex along the trail and
   * passes them to the '_toObj()' method in 'WiresModel', which handles formatting
   * the vertices and representing the trail as a polyline.
   * 
   * This template implementation is a simple version of the function. Your module may need
   * a more advanced version depending on how the trail is constructed.
   * Refer to existing built-in modules for more complex examples.
   * 
   * @returns A string in '.obj' format, listing the trail vertices and polyline.
   */
  toObj(): string {
    const coords: api.THREE.Vector3[] = [];
    for (const curE of this.trail) {
      const v1 = curE.twin.vertex; // Vertex at the opposite end of the current half-edge's edge
      coords.push(v1.coords);
    }
    return super._toObj(coords);
  }

  /**
   * Computes and returns the routing trail for this module.
   *
   * This method is intended to have the plugin's custom routing logic that computes a valid 
   * sequence of half-edges (the trail) through the input graph. You can look at the built-in 
   * modules for reference. Each implements a different routing strategy
   * 
   * The base template returns an empty array and serves as a placeholder.
   * Override this in your own module to implement your desired routing strategy.
   * 
   * @returns An array of half-edges representing the routing trail.
   */
  getRoute(): api.HalfEdge[] {
    return [];
  }

  /**
   * Returns the 3D object associated with this module's routing trail.
   * 
   * This function creates the route visualisation for the design module. It is essentially
   * the route you see when you toggle on the visibility of any module's route in DNAForge 
   * website.
   * 
   * How you generate this visualization depends on your routing logic and preferences.
   * Make sure to do the following:
   *  - Scale the coordinates using 'scaleFactor'.
   *  - Build a list of 3D coordinates based on your trail.
   *  - Pass the calculated coordinates as a 2D array ('Vector3[][]') to the method
   *    'super._generateObject()'.
   * 
   * The 'super._generateObject()' method handles the actual creation of the 3D mesh and
   * assigns it to this module’s 'obj' property.
   * 
   * Refer to built-in modules for examples of route visualizations.
   * 
   * @returns The 3D object representing the route.
   */
  generateObject() {
    const scaleFactor = this.getScaleFactor(); // Fetches the current scale factor

    if (!this.obj) { // Only generates the object if it doesn't exist yet.
      const coords: api.THREE.Vector3[] = [];

      super._generateObject([coords]); // Passing the coordinates to _generateObject() at the end
    }
    return this.obj;
  }

  /**
   * Mandatory for all 'WiresModel' subclasses
   * 
   * This function can be left to how it currently is implemented in this template, 
   * and that's what all the built-in modules do as well.
   */
  solveIntersection(i: api.THREE.Intersection): api.Selectable {
    return null;
  }
}

/**
 * Creates and initializes a routing module from the input graph.
 * 
 * This function can be left as-is if the route is initialized within the module's constructor.
 * Alternatively, you can initialize the route here, as done in some built-in modules
 * like in 'ATrail' or 'Cycle Cover'.
 * 
 * @param graph The input graph
 * @param params Parameters from the template menu
 * @returns An initialized 'Template' module instance
 */
function graphToWires(graph: api.Graph, params: TemplateParameters) {
  const module = new Template(graph, params);
  return module;
}

/**
 * Creates a cylinder model from the input routing model.
 *
 * This method generates and connects cylinders along the trail of the routing module.
 * The nucleotide strands are generated based on these cylinders. You can separate the 
 * creating and connecting to their own functions, but the menu class will use only this 
 * function.
 * 
 * The cylinder creation will again depend on your routing logic, so this provided function
 * is only a placeholder. The built-in modules could help with your implementation. The 
 * function should at least create the cylinder model based on the scale you get from 'params', 
 * and return that cylinder model in the end.
 * 
 * @param module 'Template' module instance
 * @param params Parameters from the template menu
 * @returns The created cylinder model
 */
function wiresToCylinders(module: Template, params: TemplateParameters) {
  const scale = params.scale;

  // Specify nucleic acid type ('DNA' or 'RNA')
  const cm = new api.CylinderModel(scale, 'DNA');
  return cm;
}

/**
 * Creates a nucleotide model from the input cylinder model.
 * 
 * This function is a placeholder and should be extended to work properly. See the built-in
 * modules for different kinds of possible implementations.
 * 
 * Below you can see a start of an example implementation. The function should return the
 * nucleotide model where the generated strands are properly connected. 
 *
 * @param cm Input cylinder model
 * @param params Parameters from the template menu
 * @returns Nucleotide model containing connected strands
 */
function cylindersToNucleotides(
  cm: api.CylinderModel,
  params: TemplateParameters,
) {

  const scale = cm.scale;

  // Specify nucleic acid type ('DNA' or 'RNA')
  const nm = new api.NucleotideModel(scale, 'DNA');

  // Create base-paired strands for each cylinder
  const cylToStrands = nm.createStrands(cm, true);

  // Connect complementary strands based on your routing strategy (missing here)
  // You can create a separate function for that.

  // This function should be called after the strands are connected to concatenate the 
  // connected strands to single continuous strands
  nm.concatenateStrands();

  return nm;
}

/**
 * Defines the parameters set for the Template module menu.
 * 
 * You can add any additional parameters specific to your module to this interface.
 * It inherits all base parameters from 'ModuleMenuParameters', which you can see at:
 * https://github.com/dnaforge/dnaforge/blob/main/src/scripts/menus/module_menu.ts
 * 
 * If you add new parameters, make sure to also register them in the 'setupEventListeners()'
 * function of your 'TemplateMenu' class, so they are properly linked to the UI.
 * 
 * Note that 'ModuleMenuParameters' is not exported from the API, so you can reference it 
 * directly without using the 'api.' prefix.
 */
interface TemplateParameters extends ModuleMenuParameters {
  // Add custom parameters here, e.g. 
  scaffoldOffset: number;
}

/**
 * The module menu class integrates the routing module, HTML UI, and menu parameters.
 * 
 * To make your design method appear in the DNAForge web interface, you must initialize
 * this menu with the application context in the end of this plugin file.
 * 
 * This class follows the same structure as other built-in module menus in DNAForge,
 * and extends the 'ModuleMenu' abstract class (of which you can find further information from
 * https://github.com/dnaforge/dnaforge/blob/main/src/scripts/menus/module_menu.ts).
 */
class TemplateMenu extends api.ModuleMenu {
  /**
   * Mandatory for all 'ModuleMenu' subclasses
   * 
   * Connects the menu parameters to the menu class.
   */
  params: TemplateParameters;

  /**
   * Mandatory for all 'ModuleMenu' subclasses
   * 
   * Initializes the module menu with the given application context and associated HTML UI.
   * 
   * This constructor can remain as is, but you can initialize other parameters in addition
   * to the nucleic acid type.
   * 
   * @param context The DNAForge application context used to link the menu to the app.
   */
  constructor(context: api.Context) {
    super(context, pluginHTML); // Initializes the menu with context and HTML layout
    this.params.naType = 'DNA'; // Specify nucleic acid type ('DNA' or 'RNA')
  }

  /**
   * Assigns keys to functions or buttons.
   */
  registerHotkeys() {
    super.registerHotkeys();
  }

  /**
   * Mandatory for all 'ModuleMenu' subclasses
   * 
   * Connects the menu to the module's 'loadJSON()' method and reconstructs a module instance
   * from the given JSON object.
   * 
   * This implementation typically does not need to be changed, and is the same across
   * most built-in modules' menus.
   * 
   * @param json A JSON object containing serialized information
   * @returns An instance of the module initialized with the provided JSON data
   */
  jsonToWires(json: JSONObject): api.WiresModel {
    return Template.loadJSON(json);
  }

  /**
   * Mandatory for all 'ModuleMenu' subclasses
   * 
   * Connects the menu to the module's 'graphToWires()' method and creates and initializes 
   * a routing module from the input graph and possible parameters.
   * 
   * This implementation is similar to those in built-in module menus, but you can customize
   * the message shown in the DNAForge UI to reflect your module's behavior.
   * 
   * @param graph The input graph
   * @param params Parameters from the template menu
   * @returns An initialized 'Template' module instance
   */
  graphToWires(graph: api.Graph, params: TemplateParameters) {
    const wires = graphToWires(graph, params);
    this.context.addMessage(
      `Your message here`,
      'info',
    );
    return wires;
  }

  /**
   * Mandatory for all 'ModuleMenu' subclasses
   * 
   * Connects the menu to the module's 'wiresToCylinders()' method, and generates
   * a cylinder model based on the module's routing path and the provided parameters.
   * 
   * This implementation typically does not need to be changed, and is the same across
   * most built-in modules' menus.
   * 
   * @param wires WiresModel instance
   * @param params Parameters from the template menu
   * @returns The cylinder model returned by the module's 'wiresToCylinders()'
   */
  wiresToCylinders(wires: api.WiresModel, params: TemplateParameters) {
    return wiresToCylinders(<Template>wires, params);
  }

  /**
   * Mandatory for all 'ModuleMenu' subclasses
   * 
   * Connects the menu to the module's 'cylindersToNucleotides()' method, and generates
   * a nucleotide model based on the given cylinder model and the provided parameters.
   * 
   * This implementation typically does not need to be changed, and is the same across
   * most built-in modules' menus.
   * 
   * @param cm Cylinder model
   * @param params Parameters from the template menu
   * @returns The nucleotide model returned by the module's 'cylindersToNucleotides()'
   */
  cylindersToNucleotides(cm: api.CylinderModel, params: TemplateParameters) {
    return cylindersToNucleotides(cm, params);
  }

  /**
   * Sets a user-provided nucleic acid sequence as the custom scaffold strand.
   * 
   * This is an example of a function you can do in your custom module menu class in 
   * addition to the mandatory ones.
   * 
   * @param scaffold The custom scaffold sequence as a string of nucleic acid bases (e.g. "ACGCGA...")
   */
  setCustomScaffold(scaffold: string) {
    // Set the parameters to appropriate values
    this.params.scaffoldName = 'custom';
    this.params.customScaffold = scaffold;
  }

  /**
   * Generate a primary structure with 'setPrimaryFromScaffold()' based on the current or generated 
   * nucleotide model and parameters.
   * 
   * This is an example of a function you can do in your custom module menu class that uses
   * a decorator.
   * 
   * The '@api.editOp()' function is a decorator for edit operations, and allows the change to be 
   * tracked and made undoable.
   * 
   * Use '@api.editOp()' on any method that directly modifies models 
   * (wires model ('wires') / nucleotide model ('nm') / cylinder model ('cm')).
   * For more information about the decorator(s), see:
   * https://github.com/dnaforge/dnaforge/blob/main/src/scripts/editor/editOPs.ts
   */
  @api.editOp('nm')
  generatePrimary() {
    if (!this.nm) this.generateNucleotideModel();

    this.collectParameters();

    api.setPrimaryFromScaffold(this.nm, this.params);
  }

  /**
   * Registers UI parameters and event listeners for the module menu.
   * 
   * In this method, you can link the HTML form elements to the module's parameter object ('this.params') 
   * using 'register()' function, and set up listeners.
   */
  setupEventListeners() {
    super.setupEventListeners(); // Set up the 'ModuleMenu' event listeners

    /**
     * A shorthand 'register' function bound to 'this.registerParameter'
     * 
     * This function registers a parameter, which means that it connects the html elements to the 
     * params-dictionary. It takes the following arguments:
     * 
     * @param dict The parameter object
     * @param parameter Name of the parameter written the same way as in TemplateParameters or ModuleMenuParameters
     * @param id ID of the HTML element
     * @param fromHTMLTrans Optional. Transformation from HTML value to params-value
     * @param toHTMLTrans Optional. Transformation to HTML value from params-value
     */
    const register = (this.registerParameter<TemplateParameters>).bind(this); 

    // Here's some examples on how you can use the 'register()' function. As you add your own elements to 
    // the html layout, you should register them in a similar way if you want them to affect the module.
    register(
      this.params,
      'scale',
      'template-scale',
      (t: number) => {
        return 1 / t;
      },
      (t: number) => {
        return 1 / t;
      },
    );
    register(this.params, 'scaffoldName', 'template-scaffold');
    register(this.params, 'scaffoldOffset', 'template-scaffold-offset');
    register(this.params, 'scaffoldStart', 'template-scaffold-start');
    register(
      this.params,
      'gcContent',
      'template-gc-content',
      (t: number) => {
        return t / 100;
      },
      (t: number) => {
        return t * 100;
      },
    );

    // Here's some examples of setting up listeners for HTML elements
    $('#template-scaffold').on('change', () => {
      if ($('#template-scaffold')[0].value == 'custom') {
        Metro.dialog.open('#template-scaffold-dialog');
        $('#template-scaffold-dialog-text').focus();
      }
    });

    $('#template-scaffold-dialog-confirm').on('click', () => {
      try {
        this.setCustomScaffold(
          $('#template-scaffold-dialog-text').val().toUpperCase(),
        );
      } catch (error) {
        this.context.addMessage(error, 'alert');
        throw error;
      }
    });
  }
}

// Important part of building a plugin is to initialize the menu class with 'context' for it to be visible 
// on DNAForge website. If you change the menu class's name, make sure to change this call as well.
new TemplateMenu(context);